#ifndef BECOME_A_NOBODY_H
#define BECOME_A_NOBODY_H 1

void become_a_nobody(const char *username);

#endif
