#ifndef UPDATE_PIDFILE_H
#define UPDATE_PIDFILE_H 1

void update_pidfile (char *pidfile);

#endif
